RoutineAlarm plan authority: source review package
Candidate: 0f8eb8ca8252e197d114bf81d5f340dcbd24f4a8
Full source is source-0f8eb8c.zip. candidate.patch covers parent ba78106; from-alpha11.patch covers b4996e1, whose tree matches published PR9 a09c648.
Fresh archive: 256 tests passed, zero failed/errors/skipped. Test XML and raw successful log included.
Reproduce: Java17+ and Android SDK35, Gradle8.9; gradle :app:testDebugUnitTest. On Windows use a short writable TEMP/TMP path; native SQLite fails on long paths.
This is evidence for independent review. Backup2, crash/concurrency and personal runtime admission remain unfinished. No merge, product activation, new APK or device verification.
docs/PERSONAL_PLAN_PERSISTENCE.md and PERSONAL_PLAN_REPLACEMENT.md are additive design documents outside the narrow Daily doc allowlist; explicitly review this scope difference.
See manifest.json and review.json for source identity and limitations.
